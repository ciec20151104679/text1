//
//  main.swift
//  lux2
//
//  Created by s20151104679 on 17/3/1.
//  Copyright © 2017年 s20151104679. All rights reserved.
//

import Foundation

var numbersArray = [1, 4, 6, 5, 8, 2, 3, 10, 9, 7]

for i in 0...(numbersArray.count - 2)
{
    
    
    for j in 0...(numbersArray.count - i - 2)
    {
        
        if numbersArray[j] > numbersArray[j + 1]
        {
            
            swap(&numbersArray[j], &numbersArray[j + 1])
            
        }
    }
    
}

print(numbersArray)
