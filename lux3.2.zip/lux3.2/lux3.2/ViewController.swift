//
//  ViewController.swift
//  lux3.2
//
//  Created by s20151104679 on 17/3/15.
//  Copyright © 2017年 s20151104679. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var shuchu: UILabel!
    
    var operand1: String = ""
    var operand2: String = ""
    var operator: String = "#";
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func s(_ sender: UIButton) {
        _  = sender.currentTitle
    }
    @IBAction func c(_ sender: UIButton) {
         _  = sender.currentTitle
    }
    @IBAction func seven(_ sender: UIButton) {
         _  = sender.currentTitle
    }
    
    @IBAction func eight(_ sender: UIButton) {
         _  = sender.currentTitle
    }
    
    
    if value == "+" || value == "-" || value == "x" || value == "/" {
    operator = value
    {
    operator = value
    return
    else if value == "="{
    var result = 0
    switch operator {
    case "+":
    result = operand1.toInt()! + operand2.toInt()!
    case "-":
    result = operand1.toInt()! - operand2.toInt()!
    case "x":
    result = operand1.toInt()! * operand2.toInt()!
    case "/":
    result = operand1.toInt()! / operand2.toInt()!
    default:
    result = 0
    }
    resultLabel .text = "\(result)"
    
    return
    
    }
    if operator == ""{
    operand1 = operand1 + value
    resultLable.text = operand1
    }
    else {
    operand2 = operand2 + value
    resultLable.text = operand2
    
    
    }
    }
}

