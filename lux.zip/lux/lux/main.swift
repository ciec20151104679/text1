//
//  main.swift
//  lux
//
//  Created by s20151104679 on 17/2/27.
//  Copyright © 2017年 s20151104679. All rights reserved.
//

import Foundation

print("Hello, World!")


